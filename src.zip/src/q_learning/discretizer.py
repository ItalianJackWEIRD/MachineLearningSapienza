# Implement state discretization here
