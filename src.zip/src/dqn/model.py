# Define your PyTorch model here
